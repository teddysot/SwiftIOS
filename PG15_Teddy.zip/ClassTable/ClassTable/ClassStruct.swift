//
//  ClassStruct.swift
//  ClassTable
//
//  Created by Teddy Nasahachart on 2019-05-22.
//  Copyright © 2019 Teddy Nasahachart. All rights reserved.
//

import Foundation
import UIKit

struct ClassMate {
    var name : String
    var image : UIImage
}
